import type { Metadata } from "next";
import { peekFormToken } from "@/lib/forms/tokens";
import { db } from "@/lib/supabase";
import { getShippingSettings, listCategoryOptions, listContainerOptions, listMainCities } from "@/lib/shipping/repo";
import { Shell } from "../register/Shell";
import QuoteForm from "./QuoteForm";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "حاسبة أسعار الشحن | هلال الشرق للتجارة",
  robots: { index: false, follow: false },
};

export default async function QuotePage({ searchParams }: { searchParams: Promise<{ t?: string }> }) {
  const { t = "" } = await searchParams;
  const tok = await peekFormToken(t, "quote");

  if (!tok) {
    return (
      <Shell>
        <div className="text-center py-6">
          <div className="text-5xl mb-4">⏳</div>
          <h2 className="text-xl font-bold text-[#0B1B3A] mb-2">انتهت صلاحية الرابط</h2>
          <p className="text-slate-600 leading-7">يرجى العودة إلى محادثة الواتساب واختيار «حاسبة أسعار الشحن» من القائمة، وسيصلك رابط جديد.</p>
        </div>
      </Shell>
    );
  }

  const [categories, containers, cities, settings, cust] = await Promise.all([
    listCategoryOptions(),
    listContainerOptions(),
    listMainCities(),
    getShippingSettings(),
    db().from("customers").select("code, registration_complete").eq("id", tok.customer_id).single(),
  ]);

  return (
    <Shell code={cust.data?.registration_complete ? cust.data.code : undefined}>
      <QuoteForm
        token={t}
        categories={categories}
        containers={containers}
        cities={cities}
        samples={settings.prices_are_samples}
        divisor={settings.air_volumetric_divisor}
        remoteFee={settings.remote_fee_per_carton}
        transit={{ air: settings.transit_air_ar, sea: settings.transit_sea_ar }}
        customsNotice={settings.customs_notice_ar}
      />
    </Shell>
  );
}
